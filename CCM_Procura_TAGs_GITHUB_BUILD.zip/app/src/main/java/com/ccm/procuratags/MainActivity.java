package com.ccm.procuratags;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.graphics.Color;
import android.widget.ImageView;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);

        final FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(5,10,17));

        final ImageView splash = new ImageView(this);
        splash.setImageResource(0);
        try {
            splash.setImageDrawable(android.graphics.drawable.Drawable.createFromStream(
                getAssets().open("ccm_procura_tags_splash.png"), null));
        } catch (Exception ignored) {}
        splash.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(splash, new FrameLayout.LayoutParams(-1,-1));

        final WebView web = new WebView(this);
        web.setBackgroundColor(Color.rgb(5,10,17));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setBuiltInZoomControls(false);
        web.loadUrl("file:///android_asset/index.html");

        new Handler().postDelayed(() -> {
            root.removeAllViews();
            root.addView(web, new FrameLayout.LayoutParams(-1,-1));
        }, 1800);

        setContentView(root);
    }
}
