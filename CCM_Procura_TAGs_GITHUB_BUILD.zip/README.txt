CCM • PROCURA TAGs — projeto Android

A arte enviada pelo usuário foi incorporada ao projeto:
- app/src/main/assets/ccm_procura_tags_splash.png = arte completa para a tela de abertura.
- app/src/main/res/drawable/ccm_procura_tags_icon.png = ícone derivado da própria arte.
- A tela de abertura aparece por aproximadamente 1,8 s antes da consulta.

Importe esta pasta no AndroidIDE.
A base está incorporada em app/src/main/assets/index.html.
A busca pesquisa SOMENTE o campo TAG.
Área e Sala/CCM são filtros separados.
O projeto é independente do Eletroshopp.
